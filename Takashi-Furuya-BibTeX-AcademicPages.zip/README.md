# BibTeX-driven Publications for Academic Pages

Files included:

- `_bibliography/publications.bib` — master publication list (33 entries)
- `scripts/bibtex_to_publications.py` — generates `_publications/*.md`
- `.github/workflows/update-publications.yml` — automatically regenerates publications after BibTeX changes
- `publications.md` — copy this to `_pages/publications.md`

## First setup

1. Copy `_bibliography/`, `scripts/`, and `.github/workflows/update-publications.yml` into your GitHub Pages repository.
2. Replace `_pages/publications.md` with the included `publications.md`.
3. Commit/push.
4. GitHub Actions runs the script and creates the 33 Markdown files under `_publications/`.

## Updating later

Edit only `_bibliography/publications.bib` and commit it.
The GitHub Action regenerates `_publications/` automatically.

## Notes

- The BibTeX data is based on the CV/publication list supplied in the conversation.
- arXiv links are included where arXiv IDs were supplied.
- DOI/PDF links were not invented.
- Exact publication dates were not available in the source list, so generated Markdown uses `YYYY-01-01` only as a sorting placeholder.
